import { fetchProducts } from "./api.js";

const state = {
  products: [],
  search: "",
  category: "all",
  sort: "default"
};

const productsEl = document.querySelector("#products");
const searchEl = document.querySelector("#search");
const sortEl = document.querySelector("#sort");
const categoriesEl = document.querySelector("#categories");
const loadingEl = document.querySelector("#loading");
const errorEl = document.querySelector("#error");
const statusEl = document.querySelector("#status");
const cartCountEl = document.querySelector("#cartCount");
const clearCartEl = document.querySelector("#clearCart");

let cart = JSON.parse(localStorage.getItem("task5-cart") || "[]");

function saveCart() {
  localStorage.setItem("task5-cart", JSON.stringify(cart));
  cartCountEl.textContent = cart.length;
}

function setLoading(isLoading) {
  loadingEl.hidden = !isLoading;
  if (isLoading) statusEl.textContent = "Loading products...";
}

function showError(message) {
  errorEl.textContent = message;
  errorEl.hidden = false;
  statusEl.textContent = "Error";
}

function hideError() {
  errorEl.hidden = true;
}

function getVisibleProducts() {
  let result = [...state.products];

  if (state.category !== "all") {
    result = result.filter(p => p.category === state.category);
  }

  const query = state.search.trim().toLowerCase();
  if (query) {
    result = result.filter(p => p.title.toLowerCase().includes(query));
  }

  if (state.sort === "price-asc") result.sort((a,b) => a.price - b.price);
  if (state.sort === "price-desc") result.sort((a,b) => b.price - a.price);
  if (state.sort === "title") result.sort((a,b) => a.title.localeCompare(b.title));

  return result;
}

function renderProducts() {
  const products = getVisibleProducts();
  productsEl.innerHTML = "";

  if (!products.length) {
    productsEl.innerHTML = "<p class='empty'>No products found.</p>";
    return;
  }

  products.forEach(product => {
    const card = document.createElement("article");
    card.className = "card";
    card.innerHTML = `
      <img src="${product.image}" alt="${product.title}">
      <div class="card-body">
        <span class="category">${product.category}</span>
        <h2>${product.title}</h2>
        <p class="price">$${product.price.toFixed(2)}</p>
        <button type="button" data-id="${product.id}">Add to cart</button>
      </div>`;
    productsEl.appendChild(card);
  });

  statusEl.textContent = `${products.length} product(s) shown`;
}

function addToCart(id) {
  cart.push(id);
  saveCart();
}

categoriesEl.addEventListener("click", event => {
  const button = event.target.closest("button[data-category]");
  if (!button) return;
  document.querySelectorAll("#categories button").forEach(b => b.classList.remove("active"));
  button.classList.add("active");
  state.category = button.dataset.category;
  renderProducts();
});

productsEl.addEventListener("click", event => {
  const button = event.target.closest("button[data-id]");
  if (button) addToCart(Number(button.dataset.id));
});

searchEl.addEventListener("input", event => {
  state.search = event.target.value;
  renderProducts();
});

sortEl.addEventListener("change", event => {
  state.sort = event.target.value;
  renderProducts();
});

clearCartEl.addEventListener("click", () => {
  cart = [];
  saveCart();
});

async function init() {
  hideError();
  setLoading(true);
  try {
    state.products = await fetchProducts();
    renderProducts();
  } catch (error) {
    showError("Unable to load products. Please check your connection and try again.");
  } finally {
    setLoading(false);
  }
}

saveCart();
init();
